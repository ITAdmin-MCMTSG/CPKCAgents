To install an agent on a local machine with the MSI installer, run the install.bat file. 
Ensure that the Agent_Install.msi, Agent_Install.mst, and install.bat files are all in the same directory before running.

To use the Agent_Install.msi for GPO, please navigate to the following documentation link:
https://docs.connectwise.com/ConnectWise_Automate_Documentation/040/050